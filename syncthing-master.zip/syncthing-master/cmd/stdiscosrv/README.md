stdiscosrv
==========

This is the global discovery server for the `syncthing` project.

Usage
-----

https://docs.syncthing.net/users/stdiscosrv.html

